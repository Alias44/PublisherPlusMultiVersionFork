# PublisherPlus
![](https://img.shields.io/badge/Mod_Version-1.9.0-blue.svg)
![](https://img.shields.io/badge/Built_for_RimWorld-{GameVersion}-blue.svg)
![](https://img.shields.io/badge/Powered_by_Harmony-{HarmonyVersion}-blue.svg)

[Link to Steam Workshop page](https://steamcommunity.com/sharedfiles/filedetails/?id=1510554297)

------------

Provides extended options for publishing mods to the Steam Workshop.

This 'mod' has no affect on gameplay and is only useful for mod developers uploading to the Steam platform.
